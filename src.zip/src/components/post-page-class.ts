export class UserPostClass {
  username:string;
  id:number;
  avatarPhotoUrl:string;
  location:string;
  postPhotoUrl:string;
  description:string;
  likes:any [];
  user_id:string;
}
