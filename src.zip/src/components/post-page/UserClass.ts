export class UserClass {
  username:string;
  accountInfo:string;
  id:string;
  avatarPhotoUrl:string;
}
