export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyCB4MqBa-ZaOYmc68UZISwEzpd2RLjAZQs",
  authDomain: "photoappstorage-3aade.firebaseapp.com",
  databaseURL: "https://photoappstorage-3aade.firebaseio.com",
  projectId: "photoappstorage-3aade",
  storageBucket: "photoappstorage-3aade.appspot.com",
  messagingSenderId: "409002803181"
};
